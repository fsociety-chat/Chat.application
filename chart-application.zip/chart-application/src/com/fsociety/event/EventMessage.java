package com.fsociety.event;

import com.fsociety.model.Model_Message;

public interface EventMessage {

    public void callMessage(Model_Message message);
}
